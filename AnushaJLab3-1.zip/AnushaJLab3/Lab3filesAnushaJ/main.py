# main.py

import sys
from typing import List, Tuple, TextIO
from lab3 import process_files

# define a function to open a list of files
def open_files(file_paths: List[str], mode: str) -> List[TextIO]:
    return [open(file_path, mode) for file_path in file_paths]

# define a function to close a list of files
def close_files(files: List[TextIO]) -> None:
    for file in files:
        file.close()

# define the main function
def main(input_file_paths: List[str], output_file_paths: List[str]) -> None:
    # open input and output files
    input_files = open_files(input_file_paths, 'r')
    output_files = open_files(output_file_paths, 'w')

    # process files
    process_files([(input_files[i], i == 0) for i in range(len(input_files))], output_files)

    # close input and output files
    close_files(output_files)
    close_files(input_files)

if __name__ == '__main__':
    # get input and output file paths from command line arguments
    input_file_paths = sys.argv[1:4]
    output_file_paths = [sys.argv[4]]

    # run the program
    main(input_file_paths, output_file_paths)